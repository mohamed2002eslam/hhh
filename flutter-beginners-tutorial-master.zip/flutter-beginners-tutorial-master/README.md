# flutter-beginners-tutorial
All course files for the Flutter Beginners playlist on The Net Ninja YouTube channel.

## How to use these files
Each lesson in the playlist has it's own branch in this repository. To see the code for that lesson, choose the appropriate branch. E.g. to see the code for lesson 15, checkout the lesson-15 branch.

**important** - if you are cloning the repo to your desktop, you will need to perform a packages get / pub get to install any dependencies that the project may have at that point of the course.

**Link to playlist on YouTube**
